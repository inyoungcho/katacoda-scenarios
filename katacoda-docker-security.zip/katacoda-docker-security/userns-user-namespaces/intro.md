In this scenario you'll learn how to configure User Namespaces to add additional user isolation and remap container root users to non-privileged users on the host machine.
